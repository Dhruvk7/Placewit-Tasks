export const CLIENT_ID = "c3b7e4c242b30ddef0a8";
export const CLIENT_SECRET = "c2479d45d4fb7a54fb16a3b9120e215ab68c98c8";
