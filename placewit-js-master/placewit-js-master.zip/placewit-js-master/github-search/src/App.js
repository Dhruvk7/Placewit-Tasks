import logo from './logo.svg';
import './App.css';
import GithubSearchApp from './components/GithubSearchApp';
function App() {
  return (
   <>
      <GithubSearchApp/>
   </>
  );
}

export default App;
