import React from 'react'

const Intro = () => {
  return (
    <>
        <h1>This is intro</h1>
    </>
  )
}

export default Intro