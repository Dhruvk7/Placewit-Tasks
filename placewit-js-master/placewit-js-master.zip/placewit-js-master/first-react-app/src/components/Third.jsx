import React from 'react'

const Third = ({key3}) => {
  return (
    <>
        <h5>{key3}</h5>
    </>
  )
}

export default Third