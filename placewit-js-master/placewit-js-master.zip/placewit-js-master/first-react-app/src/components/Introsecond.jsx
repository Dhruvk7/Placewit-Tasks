import React from 'react'

const Introsecond = () => {
  return (
    <>
    <h3>This is second intro</h3>
    </>
  )
}

export default Introsecond