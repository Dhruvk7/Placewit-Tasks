import React from 'react';
import './App.css';
import Canvas1 from './Components/Canvas1.js';

function App() {
  return (
    <>
      <Canvas1/>
    </>
  );
}

export default App;
